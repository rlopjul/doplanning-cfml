public class HelloWorld
{
	public HelloWorld()
	{
		//do nothing
	}

	public String hello()
	{
		return "Hello World";
	}
}